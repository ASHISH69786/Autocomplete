# Auto-complete-search-using-Atlas-Search-and-Elasticsearch
To design an autocomplete feature which displays top 10 suggestions for the input text.Suggestions need to get populated from the second word entered in the search box, with a simple UI for the auto complete search alone.
